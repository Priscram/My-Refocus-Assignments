let news1 = "there is a storm coming to the East of the Philippines";
let news = news1;
let news2 = "no more rainy days here, sun is about to show up";
news = news2;

function checkFirstUppercaseLetter(news) {
    const length = news.length;
    for (let i = 0; i < length; i++) {
        news = news1;
        const uppercaseMatch = news.match(/[A-Z]/g);
        if (uppercaseMatch[0] === uppercaseMatch[0]) {
            console.log(uppercaseMatch[0]);
            //console.log(`Climate is stormy`);
            break;
        }
    }
    for (let i = 0; i < length; i++) {
        news = news2;
        const uppercaseMatch = news.match(/[A-Z]/g);
        if (uppercaseMatch === null) {
            console.log(news2);
            //console.log(`Climate is sunny`);
        }
        break;
    }
}

checkFirstUppercaseLetter(news);