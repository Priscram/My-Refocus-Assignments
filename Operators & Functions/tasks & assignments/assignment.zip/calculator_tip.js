function computeTip(totalBill) {
    let tip = (totalBill) * .1;
    return tip;
}

console.log(computeTip(100));
console.log(computeTip(2500));